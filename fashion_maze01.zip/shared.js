document.addEventListener('DOMContentLoaded', function() {
    const navPlaceholder = document.getElementById('nav-placeholder');
    const footerPlaceholder = document.getElementById('footer-placeholder');

    // Load footer
    if (footerPlaceholder) {
        fetch('footer.html')
            .then(response => response.text())
            .then(data => footerPlaceholder.innerHTML = data);
    }

    // Load navigation and handle user state
    if (navPlaceholder) {
        fetch('nav.html')
            .then(response => response.text())
            .then(data => {
                navPlaceholder.innerHTML = data;
                updateNav();
            });
    }
});

function updateNav() {
    const user = JSON.parse(localStorage.getItem('user'));
    const loginLink = document.getElementById('login-link');
    const logoutLink = document.getElementById('logout-link');
    const userEmail = document.getElementById('user-email');
    const adminLink = document.getElementById('admin-link');

    if (user) {
        if (loginLink) loginLink.style.display = 'none';
        if (logoutLink) logoutLink.style.display = 'block';
        if (userEmail) {
            userEmail.textContent = user.email;
            userEmail.style.display = 'block';
        }
        if (adminLink && user.role === 'admin') {
            adminLink.style.display = 'block';
        }
    } else {
        if (loginLink) loginLink.style.display = 'block';
        if (logoutLink) logoutLink.style.display = 'none';
        if (userEmail) userEmail.style.display = 'none';
        if (adminLink) adminLink.style.display = 'none';
    }
}

function logout() {
    localStorage.removeItem('user');
    window.location.href = 'login.html';
} 