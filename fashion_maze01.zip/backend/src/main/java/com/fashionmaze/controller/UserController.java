package com.fashionmaze.controller;

import com.fashionmaze.model.User;
import com.fashionmaze.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
@CrossOrigin("*")
public class UserController {
    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User user) {
        if (userService.findByEmail(user.getEmail()).isPresent()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Email is already in use."));
        }
        User saved = userService.registerUser(user);
        Map<String, Object> result = new HashMap<>();
        result.put("id", saved.getId());
        result.put("name", saved.getName());
        result.put("email", saved.getEmail());
        result.put("role", saved.getRole());
        return ResponseEntity.ok(result);
    }

    @PostMapping("/login")
    public Map<String, Object> login(@RequestBody Map<String, String> payload) {
        Optional<User> userOpt = userService.findByEmail(payload.get("email"));
        Map<String, Object> result = new HashMap<>();
        if (userOpt.isPresent() && userService.checkPassword(payload.get("password"), userOpt.get().getPassword())) {
            User user = userOpt.get();
            result.put("id", user.getId());
            result.put("name", user.getName());
            result.put("email", user.getEmail());
            result.put("role", user.getRole());
        } else {
            result.put("error", "Invalid credentials");
        }
        return result;
    }
} 