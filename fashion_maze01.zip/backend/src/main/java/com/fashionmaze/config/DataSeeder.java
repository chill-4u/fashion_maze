package com.fashionmaze.config;

import com.fashionmaze.model.Product;
import com.fashionmaze.model.User;
import com.fashionmaze.repository.ProductRepository;
import com.fashionmaze.repository.UserRepository;
import com.fashionmaze.service.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

@Component
public class DataSeeder implements CommandLineRunner {

    private final ProductRepository productRepository;
    private final UserRepository userRepository;
    private final UserService userService;

    public DataSeeder(ProductRepository productRepository, UserRepository userRepository, UserService userService) {
        this.productRepository = productRepository;
        this.userRepository = userRepository;
        this.userService = userService;
    }

    @Override
    public void run(String... args) throws Exception {
        if (productRepository.count() == 0) {
            seedProducts();
        }
        if (userRepository.count() == 0) {
            seedUsers();
        }
    }

    private void seedUsers() {
        User admin = new User();
        admin.setName("Admin");
        admin.setEmail("adityanautiyal0707@gmail.com");
        admin.setPassword("1234");
        admin.setRole("admin");
        userService.registerUser(admin);
    }

    private void seedProducts() {
        List<Product> products = Arrays.asList(
            // Men's Products
            new Product("Men's Necklace", "A stylish necklace for men.", "Men", "assets/images/mens necklace.jpg", new BigDecimal("1399"), 50),
            new Product("Men's Stylish Outfit", "A complete stylish outfit for men.", "Men", "assets/images/mens stylish.jpg", new BigDecimal("4299"), 30),
            new Product("Men's Suit", "A classic men's suit for formal events.", "Suits", "assets/images/mens suit.jpg", new BigDecimal("5199"), 20),
            new Product("Men's Sweater", "A warm and comfortable sweater for men.", "Men", "assets/images/mens sweater.jpg", new BigDecimal("1499"), 60),
            new Product("Men's Jacket", "A stylish and warm jacket for men.", "Men", "assets/images/mens jacket.jpg", new BigDecimal("2199"), 40),
            new Product("Men's Casual Wear", "Comfortable casual wear for men.", "Men", "assets/images/mens casual.jpg", new BigDecimal("1899"), 60),
            new Product("Men's Traditional Wear", "Traditional attire for men.", "Men", "assets/images/mens traditional.jpg", new BigDecimal("2799"), 30),
            new Product("Men's Jeans", "Comfortable and stylish jeans for men.", "Men", "assets/images/men_jeans.jpg", new BigDecimal("1899"), 100),
            
            // Women's Products
            new Product("Women's Bangles", "A set of beautiful bangles for women.", "Women", "assets/images/womens bangles.jpg", new BigDecimal("899"), 80),
            new Product("Women's Designed Bracelet", "An intricately designed bracelet.", "Women", "assets/images/womens designed braclet.jpg", new BigDecimal("1499"), 70),
            new Product("Women's Formals", "Elegant formal wear for women.", "Women", "assets/images/womens formals.jpg", new BigDecimal("2999"), 40),
            new Product("Women's Gold Bracelet", "A beautiful gold bracelet.", "Women", "assets/images/womens gold braclet.jpg", new BigDecimal("2199"), 50),
            new Product("Women's Necklace", "An elegant necklace for women.", "Women", "assets/images/womens necklace.jpg", new BigDecimal("1299"), 60),
            new Product("Women's Sandals", "Comfortable and stylish sandals for women.", "Women", "assets/images/womens sandles.jpg", new BigDecimal("1299"), 90),
            new Product("Women's Suit", "A stylish suit for women.", "Suits", "assets/images/womens suit.jpg", new BigDecimal("3499"), 30),
            
            // Sarees
            new Product("Women's Saree", "A beautiful and elegant saree.", "Sarees", "assets/images/women_saree.jpg", new BigDecimal("2599"), 50),
            new Product("Light Blue Saree", "An elegant light blue saree.", "Sarees", "assets/images/light blue saree.jpg", new BigDecimal("2199"), 50),
            new Product("Black Saree", "A classic black saree.", "Sarees", "assets/images/black saree.jpg", new BigDecimal("2499"), 50),
            new Product("Pink Cotton Silk Saree", "A beautiful pink cotton silk saree.", "Sarees", "assets/images/Pink-Cotton-Silk-Saree.jpg", new BigDecimal("2299"), 40),

            // T-Shirts
            new Product("T-Shirt", "A comfortable cotton t-shirt.", "T-Shirts", "assets/images/t shirt.jpg", new BigDecimal("799"), 120),
            new Product("Polo Green T-Shirt", "A solid green polo t-shirt.", "T-Shirts", "assets/images/Polo_Green_Solid_T_Shirt.jpg", new BigDecimal("1099"), 90),
            new Product("Long T-Shirt", "A long style t-shirt.", "T-Shirts", "assets/images/long tshirt.jpg", new BigDecimal("899"), 80),
            new Product("Men's T-Shirt", "A stylish t-shirt for men.", "T-Shirts", "assets/images/men_tshirt.jpg", new BigDecimal("999"), 110),

            // Accessories
            new Product("Techymelter Watch", "A modern and sleek watch.", "Accessories", "assets/images/TECHYMELTER watch.jpg", new BigDecimal("4999"), 40),
            new Product("Men's Watch", "A classic watch for men.", "Accessories", "assets/images/mens watch.jpg", new BigDecimal("3999"), 40),
            new Product("Bracelet", "A stylish bracelet.", "Accessories", "assets/images/braclet.jpg", new BigDecimal("799"), 100),

            // Shoes
            new Product("NIKE Shoes", "High-performance running shoes from NIKE.", "Shoes", "assets/images/NIKE shoes.jpg", new BigDecimal("4499"), 100),
            new Product("Running Shoes", "High-performance running shoes.", "Shoes", "assets/images/running shoes.jpg", new BigDecimal("2499"), 70),
            new Product("New Balance Shoes", "Stylish and comfortable shoes from New Balance.", "Shoes", "assets/images/NEW BALANCE shoes.jpg", new BigDecimal("3299"), 80)
        );
        productRepository.saveAll(products);
    }
}
