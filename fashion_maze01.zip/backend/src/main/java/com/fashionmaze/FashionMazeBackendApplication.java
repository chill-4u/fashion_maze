package com.fashionmaze;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FashionMazeBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(FashionMazeBackendApplication.class, args);
    }
} 