package com.fashionmaze.model;

import java.math.BigDecimal;

public class Product {
    private int id;
    private String name;
    private String description;
    private BigDecimal price;
    private String gender;
    private String category;
    private String imagePath;
    private int stockQuantity;
    private boolean inStock;
    private String size;
    private String color;

    // Default constructor
    public Product() {}

    // Constructor with all fields
    public Product(int id, String name, String description, BigDecimal price, String gender, 
                   String category, String imagePath, int stockQuantity, String size, String color) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.gender = gender;
        this.category = category;
        this.imagePath = imagePath;
        this.stockQuantity = stockQuantity;
        this.inStock = stockQuantity > 0;
        this.size = size;
        this.color = color;
    }

    // Constructor without ID (for new products)
    public Product(String name, String description, BigDecimal price, String gender, 
                   String category, String imagePath, int stockQuantity, String size, String color) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.gender = gender;
        this.category = category;
        this.imagePath = imagePath;
        this.stockQuantity = stockQuantity;
        this.inStock = stockQuantity > 0;
        this.size = size;
        this.color = color;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public int getStockQuantity() {
        return stockQuantity;
    }

    public void setStockQuantity(int stockQuantity) {
        this.stockQuantity = stockQuantity;
        this.inStock = stockQuantity > 0;
    }

    public boolean isInStock() {
        return inStock;
    }

    public void setInStock(boolean inStock) {
        this.inStock = inStock;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    // Helper method to get formatted price
    public String getFormattedPrice() {
        return "₹" + price.toString();
    }

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", price=" + price +
                ", gender='" + gender + '\'' +
                ", category='" + category + '\'' +
                ", imagePath='" + imagePath + '\'' +
                ", stockQuantity=" + stockQuantity +
                ", inStock=" + inStock +
                ", size='" + size + '\'' +
                ", color='" + color + '\'' +
                '}';
    }
} 