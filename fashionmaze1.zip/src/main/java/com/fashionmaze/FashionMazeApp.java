package com.fashionmaze;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import com.fashionmaze.controller.LoginController;
import com.fashionmaze.server.EmbeddedServer;
import java.io.IOException;

public class FashionMazeApp extends Application {
    private static EmbeddedServer server;
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        // Start embedded server
        startBackend();
        
        // Start JavaFX frontend
        startFrontend(primaryStage);
    }
    
    private void startBackend() {
        try {
            server = new EmbeddedServer();
            server.start();
            System.out.println("Backend server started on port 8080");
        } catch (Exception e) {
            System.err.println("Failed to start backend server: " + e.getMessage());
            Platform.exit();
        }
    }
    
    private void startFrontend(Stage primaryStage) throws IOException {
        // Load the login FXML
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Login.fxml"));
        Parent root = loader.load();
        
        // Set up the primary stage
        primaryStage.setTitle("Fashion Maze - Login");
        primaryStage.setScene(new Scene(root, 800, 600));
        primaryStage.setMinWidth(800);
        primaryStage.setMinHeight(600);
        primaryStage.setResizable(true);
        
        // Get the controller and set the stage
        LoginController controller = loader.getController();
        controller.setPrimaryStage(primaryStage);
        
        primaryStage.show();
    }
    
    @Override
    public void stop() {
        // Stop the embedded server when application closes
        if (server != null) {
            server.stop();
            System.out.println("Backend server stopped");
        }
    }
    
    public static void main(String[] args) {
        launch(args);
    }
} 