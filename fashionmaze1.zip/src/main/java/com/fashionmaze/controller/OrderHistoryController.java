package com.fashionmaze.controller;

import com.fashionmaze.model.Order;
import com.fashionmaze.util.HttpClientUtil;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;

public class OrderHistoryController {
    @FXML private TableView<Order> orderTable;
    @FXML private TableColumn<Order, Integer> orderIdCol;
    @FXML private TableColumn<Order, String> dateCol;
    @FXML private TableColumn<Order, String> statusCol;
    @FXML private TableColumn<Order, String> amountCol;
    @FXML private Button viewDetailsButton;
    
    private ObjectMapper objectMapper = new ObjectMapper();
    private int currentUserId;
    private Stage primaryStage;

    public void setCurrentUserId(int userId) {
        this.currentUserId = userId;
        loadOrderHistory();
    }

    public void setPrimaryStage(Stage stage) {
        this.primaryStage = stage;
    }

    @FXML
    private void initialize() {
        setupTableColumns();
    }

    private void setupTableColumns() {
        orderIdCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleIntegerProperty(data.getValue().getId()).asObject());
        dateCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().getFormattedOrderDate()));
        statusCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().getStatus()));
        amountCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().getFormattedTotalAmount()));
    }

    private void loadOrderHistory() {
        try {
            String response = HttpClientUtil.sendGetRequest("http://localhost:8080/fashionmaze/orderHistory?userId=" + currentUserId);
            List<Order> orders = objectMapper.readValue(response, new TypeReference<List<Order>>() {});
            orderTable.getItems().setAll(orders);
        } catch (Exception e) {
            showAlert("Error", "Failed to load order history: " + e.getMessage());
        }
    }

    @FXML
    private void handleViewDetails() {
        Order selectedOrder = orderTable.getSelectionModel().getSelectedItem();
        if (selectedOrder == null) {
            showAlert("Error", "Please select an order to view details");
            return;
        }
        
        StringBuilder details = new StringBuilder();
        details.append("Order ID: ").append(selectedOrder.getId()).append("\n");
        details.append("Date: ").append(selectedOrder.getFormattedOrderDate()).append("\n");
        details.append("Status: ").append(selectedOrder.getStatus()).append("\n");
        details.append("Total: ").append(selectedOrder.getFormattedTotalAmount()).append("\n\n");
        details.append("Items:\n");
        
        for (Order.OrderItem item : selectedOrder.getOrderItems()) {
            details.append("- ").append(item.getProductName())
                   .append(" x").append(item.getQuantity())
                   .append(" @ ").append(item.getFormattedUnitPrice())
                   .append(" = ").append(item.getFormattedTotalPrice()).append("\n");
        }
        
        showAlert("Order Details", details.toString());
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
} 