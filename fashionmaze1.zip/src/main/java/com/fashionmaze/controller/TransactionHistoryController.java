package com.fashionmaze.controller;

import com.fashionmaze.util.HttpClientUtil;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;

public class TransactionHistoryController {
    @FXML private TableView<Map<String, Object>> transactionTable;
    @FXML private TableColumn<Map<String, Object>, Integer> orderIdCol;
    @FXML private TableColumn<Map<String, Object>, String> amountCol;
    @FXML private TableColumn<Map<String, Object>, String> dateCol;
    
    private ObjectMapper objectMapper = new ObjectMapper();
    private int currentUserId;
    private Stage primaryStage;

    public void setCurrentUserId(int userId) {
        this.currentUserId = userId;
        loadTransactionHistory();
    }

    public void setPrimaryStage(Stage stage) {
        this.primaryStage = stage;
    }

    @FXML
    private void initialize() {
        setupTableColumns();
    }

    private void setupTableColumns() {
        orderIdCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleIntegerProperty((Integer) data.getValue().get("orderId")).asObject());
        amountCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty("₹" + data.getValue().get("amount").toString()));
        dateCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().get("date").toString()));
    }

    private void loadTransactionHistory() {
        try {
            String response = HttpClientUtil.sendGetRequest("http://localhost:8080/fashionmaze/transactionHistory?userId=" + currentUserId);
            List<Map<String, Object>> transactions = objectMapper.readValue(response, new TypeReference<List<Map<String, Object>>>() {});
            transactionTable.getItems().setAll(transactions);
        } catch (Exception e) {
            showAlert("Error", "Failed to load transaction history: " + e.getMessage());
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
} 