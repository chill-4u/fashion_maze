package com.fashionmaze.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.time.LocalDate;

public class LoginController {
    @FXML private TextField loginEmailField;
    @FXML private PasswordField loginPasswordField;
    @FXML private Button loginButton;
    @FXML private Label loginErrorLabel;
    @FXML private TextField registerEmailField;
    @FXML private PasswordField registerPasswordField;
    @FXML private DatePicker registerDobPicker;
    @FXML private TextField registerAddressField;
    @FXML private ChoiceBox<String> registerUserTypeBox;
    @FXML private Button registerButton;
    @FXML private Label registerErrorLabel;
    private Stage primaryStage;

    public void setPrimaryStage(Stage stage) {
        this.primaryStage = stage;
    }

    @FXML
    private void handleLogin() {
        String email = loginEmailField.getText();
        String password = loginPasswordField.getText();
        if (email.isEmpty() || password.isEmpty()) {
            loginErrorLabel.setText("Email and password required");
            return;
        }
        // TODO: Send HTTP POST to /login servlet and handle response
        loginErrorLabel.setText("");
    }

    @FXML
    private void handleRegister() {
        String email = registerEmailField.getText();
        String password = registerPasswordField.getText();
        LocalDate dob = registerDobPicker.getValue();
        String address = registerAddressField.getText();
        String userType = registerUserTypeBox.getValue();
        if (email.isEmpty() || password.isEmpty() || dob == null || address.isEmpty() || userType == null) {
            registerErrorLabel.setText("All fields required");
            return;
        }
        // TODO: Send HTTP POST to /register servlet and handle response
        registerErrorLabel.setText("");
    }
} 