package com.fashionmaze.controller;

import com.fashionmaze.model.Product;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class ProductDetailsController {
    @FXML private ImageView productImage;
    @FXML private Label productName;
    @FXML private Label productDescription;
    @FXML private Label productPrice;
    @FXML private ChoiceBox<String> sizeChoiceBox;
    @FXML private Spinner<Integer> quantitySpinner;
    @FXML private Button addToCartButton;
    @FXML private Label statusLabel;
    private Product product;
    private int currentUserId;
    private Stage primaryStage;

    public void setProduct(Product product) {
        this.product = product;
        updateProductDetails();
    }

    public void setCurrentUserId(int userId) {
        this.currentUserId = userId;
    }

    public void setPrimaryStage(Stage stage) {
        this.primaryStage = stage;
    }

    private void updateProductDetails() {
        if (product == null) return;
        try {
            productImage.setImage(new Image(getClass().getResourceAsStream(product.getImagePath())));
        } catch (Exception e) {
            productImage.setImage(new Image(getClass().getResourceAsStream("/images/placeholder.jpg")));
        }
        productName.setText(product.getName());
        productDescription.setText(product.getDescription());
        productPrice.setText(product.getFormattedPrice());
        sizeChoiceBox.getItems().clear();
        if (product.getSize() != null && !product.getSize().isEmpty()) {
            sizeChoiceBox.getItems().add(product.getSize());
            sizeChoiceBox.setValue(product.getSize());
        } else {
            sizeChoiceBox.getItems().add("Free Size");
            sizeChoiceBox.setValue("Free Size");
        }
        quantitySpinner.getValueFactory().setValue(1);
        statusLabel.setText("");
    }

    @FXML
    private void handleAddToCart() {
        // TODO: Implement add to cart logic (update cart in backend or local session)
        statusLabel.setText("Added to cart!");
    }
} 