package com.fashionmaze.controller;

import com.fashionmaze.model.Product;
import com.fashionmaze.model.User;
import com.fashionmaze.model.Order;
import com.fashionmaze.util.HttpClientUtil;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;

public class AdminDashboardController {
    @FXML private Button addProductButton;
    @FXML private TableView<Product> productTable;
    @FXML private TableColumn<Product, String> nameCol;
    @FXML private TableColumn<Product, String> categoryCol;
    @FXML private TableColumn<Product, String> genderCol;
    @FXML private TableColumn<Product, String> priceCol;
    @FXML private TableColumn<Product, Integer> stockCol;
    @FXML private TableColumn<Product, String> actionsCol;
    
    @FXML private TableView<User> userTable;
    @FXML private TableColumn<User, String> userEmailCol;
    @FXML private TableColumn<User, String> userTypeCol;
    @FXML private TableColumn<User, String> userDobCol;
    @FXML private TableColumn<User, String> userAddressCol;
    
    @FXML private TableView<Order> orderTable;
    @FXML private TableColumn<Order, Integer> orderIdCol;
    @FXML private TableColumn<Order, String> orderUserCol;
    @FXML private TableColumn<Order, String> orderDateCol;
    @FXML private TableColumn<Order, String> orderStatusCol;
    @FXML private TableColumn<Order, String> orderAmountCol;
    
    @FXML private TableView<Map<String, Object>> transactionTable;
    @FXML private TableColumn<Map<String, Object>, Integer> txOrderIdCol;
    @FXML private TableColumn<Map<String, Object>, String> txAmountCol;
    @FXML private TableColumn<Map<String, Object>, String> txDateCol;
    
    private ObjectMapper objectMapper = new ObjectMapper();
    private Stage primaryStage;

    public void setPrimaryStage(Stage stage) {
        this.primaryStage = stage;
        loadDashboardData();
    }

    @FXML
    private void initialize() {
        setupTableColumns();
    }

    private void setupTableColumns() {
        // Product table columns
        nameCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().getName()));
        categoryCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().getCategory()));
        genderCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().getGender()));
        priceCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().getFormattedPrice()));
        stockCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleIntegerProperty(data.getValue().getStockQuantity()).asObject());
        
        // User table columns
        userEmailCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().getEmail()));
        userTypeCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().getUserType()));
        userDobCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().getDateOfBirth().toString()));
        userAddressCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().getAddress()));
        
        // Order table columns
        orderIdCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleIntegerProperty(data.getValue().getId()).asObject());
        orderUserCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty("User " + data.getValue().getUserId()));
        orderDateCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().getFormattedOrderDate()));
        orderStatusCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().getStatus()));
        orderAmountCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().getFormattedTotalAmount()));
        
        // Transaction table columns
        txOrderIdCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleIntegerProperty((Integer) data.getValue().get("orderId")).asObject());
        txAmountCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty("₹" + data.getValue().get("amount").toString()));
        txDateCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().get("date").toString()));
    }

    private void loadDashboardData() {
        try {
            String response = HttpClientUtil.sendGetRequest("http://localhost:8080/fashionmaze/admin/dashboard");
            Map<String, Object> dashboard = objectMapper.readValue(response, Map.class);
            
            // Load products
            List<Product> products = objectMapper.convertValue(dashboard.get("products"), new TypeReference<List<Product>>() {});
            productTable.getItems().setAll(products);
            
            // Load users
            List<User> users = objectMapper.convertValue(dashboard.get("users"), new TypeReference<List<User>>() {});
            userTable.getItems().setAll(users);
            
            // Load orders
            List<Order> orders = objectMapper.convertValue(dashboard.get("orders"), new TypeReference<List<Order>>() {});
            orderTable.getItems().setAll(orders);
            
        } catch (Exception e) {
            showAlert("Error", "Failed to load dashboard data: " + e.getMessage());
        }
    }

    @FXML
    private void handleAddProduct() {
        // TODO: Open add product dialog
        showAlert("Info", "Add Product functionality will be implemented");
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
} 