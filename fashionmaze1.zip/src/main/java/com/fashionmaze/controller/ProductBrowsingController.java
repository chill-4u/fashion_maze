package com.fashionmaze.controller;

import com.fashionmaze.model.Product;
import com.fashionmaze.util.HttpClientUtil;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class ProductBrowsingController {
    @FXML private ChoiceBox<String> genderFilter;
    @FXML private ChoiceBox<String> categoryFilter;
    @FXML private TextField minPriceField;
    @FXML private TextField maxPriceField;
    @FXML private CheckBox inStockOnly;
    @FXML private Button applyFiltersButton;
    @FXML private Button clearFiltersButton;
    @FXML private TextField searchField;
    @FXML private Button searchButton;
    @FXML private GridPane productsGrid;
    @FXML private Button cartButton;
    @FXML private Button orderHistoryButton;
    @FXML private Button logoutButton;
    
    private List<Product> allProducts;
    private ObjectMapper objectMapper = new ObjectMapper();
    private Stage primaryStage;
    private int currentUserId;

    public void initialize() {
        setupFilters();
        loadProducts();
    }

    public void setPrimaryStage(Stage stage) {
        this.primaryStage = stage;
    }

    public void setCurrentUserId(int userId) {
        this.currentUserId = userId;
    }

    private void setupFilters() {
        genderFilter.setItems(FXCollections.observableArrayList("All", "Men", "Women"));
        categoryFilter.setItems(FXCollections.observableArrayList("All", "T-shirts", "Jeans", "Sarees", "Suits", "Shoes", "Bags"));
        genderFilter.setValue("All");
        categoryFilter.setValue("All");
    }

    private void loadProducts() {
        try {
            String response = HttpClientUtil.sendGetRequest("http://localhost:8080/fashionmaze/products");
            allProducts = objectMapper.readValue(response, new TypeReference<List<Product>>() {});
            displayProducts(allProducts);
        } catch (Exception e) {
            showAlert("Error", "Failed to load products: " + e.getMessage());
        }
    }

    @FXML
    private void applyFilters() {
        List<Product> filteredProducts = allProducts;
        
        if (!genderFilter.getValue().equals("All")) {
            filteredProducts = filteredProducts.stream()
                .filter(p -> p.getGender().equals(genderFilter.getValue()))
                .collect(java.util.stream.Collectors.toList());
        }
        
        if (!categoryFilter.getValue().equals("All")) {
            filteredProducts = filteredProducts.stream()
                .filter(p -> p.getCategory().equals(categoryFilter.getValue()))
                .collect(java.util.stream.Collectors.toList());
        }
        
        if (!minPriceField.getText().isEmpty()) {
            try {
                BigDecimal minPrice = new BigDecimal(minPriceField.getText());
                filteredProducts = filteredProducts.stream()
                    .filter(p -> p.getPrice().compareTo(minPrice) >= 0)
                    .collect(java.util.stream.Collectors.toList());
            } catch (NumberFormatException e) {
                showAlert("Error", "Invalid minimum price");
                return;
            }
        }
        
        if (!maxPriceField.getText().isEmpty()) {
            try {
                BigDecimal maxPrice = new BigDecimal(maxPriceField.getText());
                filteredProducts = filteredProducts.stream()
                    .filter(p -> p.getPrice().compareTo(maxPrice) <= 0)
                    .collect(java.util.stream.Collectors.toList());
            } catch (NumberFormatException e) {
                showAlert("Error", "Invalid maximum price");
                return;
            }
        }
        
        if (inStockOnly.isSelected()) {
            filteredProducts = filteredProducts.stream()
                .filter(Product::isInStock)
                .collect(java.util.stream.Collectors.toList());
        }
        
        displayProducts(filteredProducts);
    }

    @FXML
    private void clearFilters() {
        genderFilter.setValue("All");
        categoryFilter.setValue("All");
        minPriceField.clear();
        maxPriceField.clear();
        inStockOnly.setSelected(false);
        displayProducts(allProducts);
    }

    @FXML
    private void searchProducts() {
        String searchTerm = searchField.getText().trim();
        if (searchTerm.isEmpty()) {
            displayProducts(allProducts);
            return;
        }
        
        List<Product> searchResults = allProducts.stream()
            .filter(p -> p.getName().toLowerCase().contains(searchTerm.toLowerCase()) ||
                        p.getDescription().toLowerCase().contains(searchTerm.toLowerCase()))
            .collect(java.util.stream.Collectors.toList());
        
        displayProducts(searchResults);
    }

    private void displayProducts(List<Product> products) {
        productsGrid.getChildren().clear();
        int col = 0;
        int row = 0;
        int maxCols = 4;
        
        for (Product product : products) {
            VBox productCard = createProductCard(product);
            productsGrid.add(productCard, col, row);
            col++;
            if (col >= maxCols) {
                col = 0;
                row++;
            }
        }
    }

    private VBox createProductCard(Product product) {
        VBox card = new VBox(5);
        card.setStyle("-fx-border-color: #ccc; -fx-border-radius: 5; -fx-padding: 10; -fx-background-color: white;");
        card.setPrefWidth(200);
        card.setPrefHeight(300);
        
        ImageView imageView = new ImageView();
        imageView.setFitWidth(180);
        imageView.setFitHeight(150);
        try {
            Image image = new Image(getClass().getResourceAsStream(product.getImagePath()));
            imageView.setImage(image);
        } catch (Exception e) {
            // Use placeholder image
            imageView.setImage(new Image(getClass().getResourceAsStream("/images/placeholder.jpg")));
        }
        
        Label nameLabel = new Label(product.getName());
        nameLabel.setStyle("-fx-font-weight: bold;");
        nameLabel.setWrapText(true);
        
        Label priceLabel = new Label(product.getFormattedPrice());
        priceLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #e74c3c;");
        
        Label stockLabel = new Label(product.isInStock() ? "In Stock" : "Out of Stock");
        stockLabel.setStyle("-fx-text-fill: " + (product.isInStock() ? "green" : "red") + ";");
        
        Button viewButton = new Button("View Details");
        viewButton.setOnAction(e -> openProductDetails(product));
        
        Button addToCartButton = new Button("Add to Cart");
        addToCartButton.setOnAction(e -> addToCart(product));
        addToCartButton.setDisable(!product.isInStock());
        
        card.getChildren().addAll(imageView, nameLabel, priceLabel, stockLabel, viewButton, addToCartButton);
        return card;
    }

    private void openProductDetails(Product product) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/ProductDetails.fxml"));
            Parent root = loader.load();
            ProductDetailsController controller = loader.getController();
            controller.setProduct(product);
            controller.setCurrentUserId(currentUserId);
            controller.setPrimaryStage(primaryStage);
            
            Stage stage = new Stage();
            stage.setTitle("Product Details - " + product.getName());
            stage.setScene(new Scene(root, 600, 500));
            stage.show();
        } catch (IOException e) {
            showAlert("Error", "Failed to open product details: " + e.getMessage());
        }
    }

    private void addToCart(Product product) {
        // TODO: Implement cart functionality
        showAlert("Success", "Product added to cart!");
    }

    @FXML
    private void openCart() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Cart.fxml"));
            Parent root = loader.load();
            CartController controller = loader.getController();
            controller.setCurrentUserId(currentUserId);
            controller.setPrimaryStage(primaryStage);
            
            Stage stage = new Stage();
            stage.setTitle("Shopping Cart");
            stage.setScene(new Scene(root, 800, 600));
            stage.show();
        } catch (IOException e) {
            showAlert("Error", "Failed to open cart: " + e.getMessage());
        }
    }

    @FXML
    private void openOrderHistory() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/OrderHistory.fxml"));
            Parent root = loader.load();
            OrderHistoryController controller = loader.getController();
            controller.setCurrentUserId(currentUserId);
            controller.setPrimaryStage(primaryStage);
            
            Stage stage = new Stage();
            stage.setTitle("Order History");
            stage.setScene(new Scene(root, 800, 600));
            stage.show();
        } catch (IOException e) {
            showAlert("Error", "Failed to open order history: " + e.getMessage());
        }
    }

    @FXML
    private void handleLogout() {
        try {
            HttpClientUtil.sendPostRequest("http://localhost:8080/fashionmaze/logout", new HashMap<>());
            // Return to login screen
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Login.fxml"));
            Parent root = loader.load();
            LoginController controller = loader.getController();
            controller.setPrimaryStage(primaryStage);
            
            primaryStage.setTitle("Fashion Maze - Login");
            primaryStage.setScene(new Scene(root, 800, 600));
        } catch (Exception e) {
            showAlert("Error", "Logout failed: " + e.getMessage());
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
} 