package com.fashionmaze.controller;

import com.fashionmaze.model.Order;
import com.fashionmaze.model.Order.OrderItem;
import com.fashionmaze.util.HttpClientUtil;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class CartController {
    @FXML private TableView<OrderItem> cartTable;
    @FXML private TableColumn<OrderItem, String> productNameCol;
    @FXML private TableColumn<OrderItem, Integer> quantityCol;
    @FXML private TableColumn<OrderItem, String> priceCol;
    @FXML private TableColumn<OrderItem, String> totalCol;
    @FXML private Label totalLabel;
    @FXML private Button placeOrderButton;
    @FXML private Label statusLabel;
    
    private List<OrderItem> cartItems = new ArrayList<>();
    private ObjectMapper objectMapper = new ObjectMapper();
    private int currentUserId;
    private Stage primaryStage;

    public void setCurrentUserId(int userId) {
        this.currentUserId = userId;
    }

    public void setPrimaryStage(Stage stage) {
        this.primaryStage = stage;
    }

    @FXML
    private void initialize() {
        setupTableColumns();
        updateTotal();
    }

    private void setupTableColumns() {
        productNameCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().getProductName()));
        quantityCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleIntegerProperty(data.getValue().getQuantity()).asObject());
        priceCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().getFormattedUnitPrice()));
        totalCol.setCellValueFactory(data -> 
            new javafx.beans.property.SimpleStringProperty(data.getValue().getFormattedTotalPrice()));
    }

    public void addToCart(OrderItem item) {
        cartItems.add(item);
        cartTable.getItems().add(item);
        updateTotal();
    }

    private void updateTotal() {
        BigDecimal total = cartItems.stream()
            .map(OrderItem::getTotalPrice)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        totalLabel.setText("₹" + total.toString());
    }

    @FXML
    private void handlePlaceOrder() {
        if (cartItems.isEmpty()) {
            showAlert("Error", "Cart is empty!");
            return;
        }

        try {
            BigDecimal total = cartItems.stream()
                .map(OrderItem::getTotalPrice)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

            Order order = new Order(currentUserId, cartItems, total, "User Address", "Credit Card");
            
            String orderJson = objectMapper.writeValueAsString(order);
            String response = HttpClientUtil.sendPostRequest("http://localhost:8080/fashionmaze/placeOrder", orderJson);
            
            if (response.contains("success")) {
                showAlert("Success", "Order placed successfully!");
                cartItems.clear();
                cartTable.getItems().clear();
                updateTotal();
            } else {
                showAlert("Error", "Failed to place order");
            }
        } catch (Exception e) {
            showAlert("Error", "Error placing order: " + e.getMessage());
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
} 