package com.fashionmaze.util;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import java.io.IOException;
import java.util.Map;

public class HttpClientUtil {
    private static final HttpClient httpClient = HttpClients.createDefault();
    
    public static String sendGetRequest(String url) throws IOException {
        HttpGet request = new HttpGet(url);
        HttpResponse response = httpClient.execute(request);
        return EntityUtils.toString(response.getEntity());
    }
    
    public static String sendPostRequest(String url, Map<String, String> params) throws IOException {
        HttpPost request = new HttpPost(url);
        StringBuilder postData = new StringBuilder();
        for (Map.Entry<String, String> param : params.entrySet()) {
            if (postData.length() != 0) postData.append('&');
            postData.append(param.getKey()).append('=').append(param.getValue());
        }
        request.setEntity(new StringEntity(postData.toString()));
        HttpResponse response = httpClient.execute(request);
        return EntityUtils.toString(response.getEntity());
    }
    
    public static String sendPostRequest(String url, String jsonData) throws IOException {
        HttpPost request = new HttpPost(url);
        request.setEntity(new StringEntity(jsonData));
        request.setHeader("Content-Type", "application/json");
        HttpResponse response = httpClient.execute(request);
        return EntityUtils.toString(response.getEntity());
    }
} 