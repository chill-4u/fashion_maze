package com.fashionmaze.servlet;

import com.fashionmaze.dao.OrderDAO;
import com.fashionmaze.model.Order;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/placeOrder")
public class PlaceOrderServlet extends HttpServlet {
    private OrderDAO orderDAO = new OrderDAO();
    private ObjectMapper objectMapper = new ObjectMapper();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Order order = objectMapper.readValue(req.getReader(), Order.class);
        resp.setContentType("application/json");
        boolean success = orderDAO.placeOrder(order);
        if (success) {
            resp.getWriter().write("{\"success\":true}");
        } else {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"error\":\"Order placement failed\"}");
        }
    }
} 