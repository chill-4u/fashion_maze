package com.fashionmaze.servlet;

import com.fashionmaze.dao.UserDAO;
import com.fashionmaze.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    private UserDAO userDAO = new UserDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String dob = req.getParameter("dob");
        String address = req.getParameter("address");
        String userType = req.getParameter("userType");
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();
        if (email == null || password == null || dob == null || address == null || userType == null) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.write("{\"error\":\"All fields required\"}");
            return;
        }
        if (userDAO.emailExists(email)) {
            resp.setStatus(HttpServletResponse.SC_CONFLICT);
            out.write("{\"error\":\"Email already exists\"}");
            return;
        }
        User user = new User(email, password, LocalDate.parse(dob), address, userType);
        boolean success = userDAO.registerUser(user);
        if (success) {
            out.write("{\"success\":true}");
        } else {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.write("{\"error\":\"Registration failed\"}");
        }
    }
} 