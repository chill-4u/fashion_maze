package com.fashionmaze.servlet;

import com.fashionmaze.dao.ProductDAO;
import com.fashionmaze.dao.UserDAO;
import com.fashionmaze.dao.OrderDAO;
import com.fashionmaze.model.Product;
import com.fashionmaze.model.User;
import com.fashionmaze.model.Order;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/admin/dashboard")
public class AdminDashboardServlet extends HttpServlet {
    private ProductDAO productDAO = new ProductDAO();
    private UserDAO userDAO = new UserDAO();
    private OrderDAO orderDAO = new OrderDAO();
    private ObjectMapper objectMapper = new ObjectMapper();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Map<String, Object> dashboard = new HashMap<>();
        dashboard.put("products", productDAO.getAllProducts());
        dashboard.put("users", userDAO.getAllUsers());
        dashboard.put("orders", orderDAO.getAllOrders());
        // For demo, transactions can be added similarly
        resp.setContentType("application/json");
        objectMapper.writeValue(resp.getWriter(), dashboard);
    }
} 