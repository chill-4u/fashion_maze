package com.fashionmaze.servlet;

import com.fashionmaze.dao.ProductDAO;
import com.fashionmaze.model.Product;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;

@WebServlet("/admin/addProduct")
public class AddProductServlet extends HttpServlet {
    private ProductDAO productDAO = new ProductDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("name");
        String description = req.getParameter("description");
        String price = req.getParameter("price");
        String gender = req.getParameter("gender");
        String category = req.getParameter("category");
        String imagePath = req.getParameter("imagePath");
        String stockQuantity = req.getParameter("stockQuantity");
        String size = req.getParameter("size");
        String color = req.getParameter("color");
        resp.setContentType("application/json");
        if (name == null || price == null || gender == null || category == null || imagePath == null || stockQuantity == null) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\":\"Missing required fields\"}");
            return;
        }
        Product product = new Product(name, description, new BigDecimal(price), gender, category, imagePath, Integer.parseInt(stockQuantity), size, color);
        boolean success = productDAO.addProduct(product);
        if (success) {
            resp.getWriter().write("{\"success\":true}");
        } else {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"error\":\"Failed to add product\"}");
        }
    }
} 