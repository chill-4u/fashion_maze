-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    date_of_birth DATE NOT NULL,
    address VARCHAR(255) NOT NULL,
    user_type VARCHAR(20) NOT NULL,
    created_at DATE NOT NULL
);

-- Admin table
CREATE TABLE admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    full_name VARCHAR(100),
    role VARCHAR(20) NOT NULL,
    created_at DATETIME NOT NULL,
    is_active BOOLEAN DEFAULT TRUE
);

-- Products table
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    gender VARCHAR(10) NOT NULL,
    category VARCHAR(50) NOT NULL,
    image_path VARCHAR(255),
    stock_quantity INT NOT NULL,
    size VARCHAR(20),
    color VARCHAR(30)
);

-- Orders table
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    status VARCHAR(20) NOT NULL,
    order_date DATETIME NOT NULL,
    shipping_address VARCHAR(255),
    payment_method VARCHAR(50),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Order Items table
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    product_name VARCHAR(100),
    product_image VARCHAR(255),
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Transactions table
CREATE TABLE transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    date DATETIME NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id)
);

-- Sample admin
INSERT INTO admin (username, password, email, full_name, role, created_at, is_active) VALUES
('admin', 'admin123', 'admin@fashionmaze.com', 'Admin User', 'SUPERADMIN', NOW(), TRUE);

-- Sample categories and products
INSERT INTO products (name, description, price, gender, category, image_path, stock_quantity, size, color) VALUES
('Men T-shirt', 'Cotton T-shirt', 499.00, 'Men', 'T-shirts', '/images/men_tshirt.jpg', 50, 'M', 'Blue'),
('Women Saree', 'Silk Saree', 1999.00, 'Women', 'Sarees', '/images/women_saree.jpg', 20, 'Free', 'Red'),
('Men Jeans', 'Denim Jeans', 999.00, 'Men', 'Jeans', '/images/men_jeans.jpg', 30, '32', 'Black'),
('Women Suit', 'Designer Suit', 1499.00, 'Women', 'Suits', '/images/women_suit.jpg', 15, 'L', 'Green'); 