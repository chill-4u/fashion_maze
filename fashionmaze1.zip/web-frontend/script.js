// Sample data
let products = [
    { id: 1, name: "Men T-shirt", description: "Cotton T-shirt", price: 499.00, gender: "Men", category: "T-shirts", stock: 50, size: "M", color: "Blue" },
    { id: 2, name: "Women Saree", description: "Silk Saree", price: 1999.00, gender: "Women", category: "Sarees", stock: 20, size: "Free", color: "Red" },
    { id: 3, name: "Men Jeans", description: "Denim Jeans", price: 999.00, gender: "Men", category: "Jeans", stock: 30, size: "32", color: "Black" },
    { id: 4, name: "Women Suit", description: "Designer Suit", price: 1499.00, gender: "Women", category: "Suits", stock: 15, size: "L", color: "Green" }
];

let cart = [];
let currentUser = null;
let orders = [];

// Navigation functions
function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.remove('active');
    });
    document.getElementById(screenId).classList.add('active');
}

function showSection(sectionId) {
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(sectionId).classList.add('active');
}

// Login functions
function showLogin() {
    showScreen('loginScreen');
}

function showRegister() {
    showScreen('registerScreen');
}

function showAdminLogin() {
    showScreen('adminLoginScreen');
}

function login() {
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    if (email && password) {
        currentUser = { email, id: 1 };
        showScreen('mainScreen');
        loadProducts();
        updateCartCount();
    } else {
        alert('Please enter valid credentials');
    }
}

function register() {
    const email = document.getElementById('regEmail').value;
    const password = document.getElementById('regPassword').value;
    const dob = document.getElementById('regDob').value;
    const address = document.getElementById('regAddress').value;
    const userType = document.getElementById('regUserType').value;
    
    if (email && password && dob && address) {
        alert('Registration successful!');
        showLogin();
    } else {
        alert('Please fill all fields');
    }
}

function adminLogin() {
    const username = document.getElementById('adminUsername').value;
    const password = document.getElementById('adminPassword').value;
    
    if (username === 'admin' && password === 'admin123') {
        showScreen('adminScreen');
        loadAdminProducts();
    } else {
        alert('Invalid admin credentials');
    }
}

function logout() {
    currentUser = null;
    cart = [];
    showLogin();
}

function adminLogout() {
    showLogin();
}

// Product functions
function loadProducts() {
    const productsGrid = document.getElementById('productsGrid');
    productsGrid.innerHTML = '';
    
    products.forEach(product => {
        const productCard = createProductCard(product);
        productsGrid.appendChild(productCard);
    });
}

function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.innerHTML = `
        <h3>${product.name}</h3>
        <p>${product.description}</p>
        <div class="product-info">
            <span class="product-price">₹${product.price}</span>
            <span class="product-stock">Stock: ${product.stock}</span>
        </div>
        <div class="product-info">
            <span>${product.gender} | ${product.category}</span>
            <span>Size: ${product.size} | Color: ${product.color}</span>
        </div>
        <div class="product-actions">
            <button class="add-to-cart" onclick="addToCart(${product.id})">Add to Cart</button>
            <button class="view-details" onclick="viewProductDetails(${product.id})">View Details</button>
        </div>
    `;
    return card;
}

function filterProducts() {
    const genderFilter = document.getElementById('genderFilter').value;
    const categoryFilter = document.getElementById('categoryFilter').value;
    
    let filteredProducts = products;
    
    if (genderFilter) {
        filteredProducts = filteredProducts.filter(p => p.gender === genderFilter);
    }
    
    if (categoryFilter) {
        filteredProducts = filteredProducts.filter(p => p.category === categoryFilter);
    }
    
    const productsGrid = document.getElementById('productsGrid');
    productsGrid.innerHTML = '';
    
    filteredProducts.forEach(product => {
        const productCard = createProductCard(product);
        productsGrid.appendChild(productCard);
    });
}

function searchProducts() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    
    const filteredProducts = products.filter(product => 
        product.name.toLowerCase().includes(searchTerm) || 
        product.description.toLowerCase().includes(searchTerm)
    );
    
    const productsGrid = document.getElementById('productsGrid');
    productsGrid.innerHTML = '';
    
    filteredProducts.forEach(product => {
        const productCard = createProductCard(product);
        productsGrid.appendChild(productCard);
    });
}

function viewProductDetails(productId) {
    const product = products.find(p => p.id === productId);
    if (product) {
        alert(`Product Details:\nName: ${product.name}\nDescription: ${product.description}\nPrice: ₹${product.price}\nGender: ${product.gender}\nCategory: ${product.category}\nStock: ${product.stock}\nSize: ${product.size}\nColor: ${product.color}`);
    }
}

// Cart functions
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (product) {
        const existingItem = cart.find(item => item.id === productId);
        if (existingItem) {
            existingItem.quantity++;
        } else {
            cart.push({ ...product, quantity: 1 });
        }
        updateCartCount();
        alert('Product added to cart!');
    }
}

function updateCartCount() {
    const cartCount = cart.reduce((total, item) => total + item.quantity, 0);
    document.getElementById('cartCount').textContent = cartCount;
}

function showCart() {
    showSection('cartSection');
    loadCart();
}

function loadCart() {
    const cartItems = document.getElementById('cartItems');
    const cartTotal = document.getElementById('cartTotal');
    
    if (cart.length === 0) {
        cartItems.innerHTML = '<p>Your cart is empty</p>';
        cartTotal.textContent = '0';
        return;
    }
    
    cartItems.innerHTML = '';
    let total = 0;
    
    cart.forEach(item => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;
        
        const cartItem = document.createElement('div');
        cartItem.className = 'cart-item';
        cartItem.innerHTML = `
            <div class="cart-item-info">
                <h4>${item.name}</h4>
                <p>₹${item.price} x ${item.quantity} = ₹${itemTotal}</p>
            </div>
            <div class="cart-item-actions">
                <button onclick="removeFromCart(${item.id})">Remove</button>
            </div>
        `;
        cartItems.appendChild(cartItem);
    });
    
    cartTotal.textContent = total.toFixed(2);
}

function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    updateCartCount();
    loadCart();
}

function checkout() {
    if (cart.length === 0) {
        alert('Your cart is empty');
        return;
    }
    
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const order = {
        id: orders.length + 1,
        userId: currentUser.id,
        items: [...cart],
        total: total,
        date: new Date().toLocaleDateString(),
        status: 'Pending'
    };
    
    orders.push(order);
    cart = [];
    updateCartCount();
    alert(`Order placed successfully! Total: ₹${total.toFixed(2)}`);
    showProducts();
}

// Order functions
function showOrderHistory() {
    showSection('orderHistorySection');
    loadOrderHistory();
}

function loadOrderHistory() {
    const orderHistory = document.getElementById('orderHistory');
    
    if (orders.length === 0) {
        orderHistory.innerHTML = '<p>No orders found</p>';
        return;
    }
    
    orderHistory.innerHTML = '';
    orders.forEach(order => {
        const orderDiv = document.createElement('div');
        orderDiv.className = 'cart-item';
        orderDiv.innerHTML = `
            <div>
                <h4>Order #${order.id}</h4>
                <p>Date: ${order.date}</p>
                <p>Status: ${order.status}</p>
                <p>Total: ₹${order.total.toFixed(2)}</p>
            </div>
        `;
        orderHistory.appendChild(orderDiv);
    });
}

// Admin functions
function loadAdminProducts() {
    const adminProductsGrid = document.getElementById('adminProductsGrid');
    adminProductsGrid.innerHTML = '';
    
    products.forEach(product => {
        const productCard = createAdminProductCard(product);
        adminProductsGrid.appendChild(productCard);
    });
}

function createAdminProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.innerHTML = `
        <h3>${product.name}</h3>
        <p>${product.description}</p>
        <div class="product-info">
            <span class="product-price">₹${product.price}</span>
            <span class="product-stock">Stock: ${product.stock}</span>
        </div>
        <div class="product-info">
            <span>${product.gender} | ${product.category}</span>
            <span>Size: ${product.size} | Color: ${product.color}</span>
        </div>
        <div class="product-actions">
            <button class="view-details" onclick="editProduct(${product.id})">Edit</button>
            <button class="add-to-cart" onclick="deleteProduct(${product.id})">Delete</button>
        </div>
    `;
    return card;
}

function showAdminProducts() {
    showSection('adminProductsSection');
}

function showAdminOrders() {
    showSection('adminOrdersSection');
    loadAdminOrders();
}

function loadAdminOrders() {
    const adminOrders = document.getElementById('adminOrders');
    
    if (orders.length === 0) {
        adminOrders.innerHTML = '<p>No orders found</p>';
        return;
    }
    
    adminOrders.innerHTML = '';
    orders.forEach(order => {
        const orderDiv = document.createElement('div');
        orderDiv.className = 'cart-item';
        orderDiv.innerHTML = `
            <div>
                <h4>Order #${order.id}</h4>
                <p>User ID: ${order.userId}</p>
                <p>Date: ${order.date}</p>
                <p>Status: ${order.status}</p>
                <p>Total: ₹${order.total.toFixed(2)}</p>
            </div>
        `;
        adminOrders.appendChild(orderDiv);
    });
}

function showAddProduct() {
    showSection('addProductSection');
}

function addProduct() {
    const name = document.getElementById('productName').value;
    const description = document.getElementById('productDescription').value;
    const price = parseFloat(document.getElementById('productPrice').value);
    const gender = document.getElementById('productGender').value;
    const category = document.getElementById('productCategory').value;
    const stock = parseInt(document.getElementById('productStock').value);
    const size = document.getElementById('productSize').value;
    const color = document.getElementById('productColor').value;
    
    if (name && description && price && gender && category && stock && size && color) {
        const newProduct = {
            id: products.length + 1,
            name,
            description,
            price,
            gender,
            category,
            stock,
            size,
            color
        };
        
        products.push(newProduct);
        alert('Product added successfully!');
        
        // Clear form
        document.getElementById('productName').value = '';
        document.getElementById('productDescription').value = '';
        document.getElementById('productPrice').value = '';
        document.getElementById('productGender').value = '';
        document.getElementById('productCategory').value = '';
        document.getElementById('productStock').value = '';
        document.getElementById('productSize').value = '';
        document.getElementById('productColor').value = '';
        
        showAdminProducts();
        loadAdminProducts();
    } else {
        alert('Please fill all fields');
    }
}

function editProduct(productId) {
    alert('Edit functionality would be implemented here');
}

function deleteProduct(productId) {
    if (confirm('Are you sure you want to delete this product?')) {
        products = products.filter(p => p.id !== productId);
        loadAdminProducts();
        alert('Product deleted successfully!');
    }
}

// Navigation functions for main app
function showProducts() {
    showSection('productsSection');
}

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    // App is ready
}); 